import { Caballo } from './caballo';

describe('Caballo', () => {
  it('should create an instance', () => {
    expect(new Caballo()).toBeTruthy();
  });
});
