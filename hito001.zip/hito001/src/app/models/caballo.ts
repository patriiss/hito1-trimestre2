export class Caballo {
    id: number = 0;
    nombre: string;
    raza: string;
}
