import { Component, OnInit } from '@angular/core';
import { Caballo } from '../models/caballo';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  caballoArray: Caballo[] = [
    { id: 1, nombre: "Albariño", raza: "PRE" },
    { id: 2, nombre: "Legionario", raza: "Arabe" },
    { id: 3, nombre: "Luna", raza: "PRE" }

  ];

  selectedCaballo: Caballo = new Caballo();


  openForEdit(caballo: Caballo) {
    this.selectedCaballo = caballo;
  }


  addOrEdit() {

    if (this.selectedCaballo.id === 0) {
      this.selectedCaballo.id = this.caballoArray.length + 1;
      this.caballoArray.push(this.selectedCaballo);
    }

    this.selectedCaballo = new Caballo();
  }

  delete(){

    if(confirm('ESTAS SEGURO DE ELIMINAR?')){
      this.caballoArray = this.caballoArray.filter(x => x != this.selectedCaballo);
    this.selectedCaballo = new Caballo();
    }
    
    
  }

  constructor() { }

  ngOnInit(): void {
  }

}
